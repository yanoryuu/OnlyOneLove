using UnityEngine;

public static class CardPlayConst
{

    public static int maxHoldCardNum = 8;
}
