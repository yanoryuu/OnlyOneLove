using UnityEngine;

public class AngelTalkView : MonoBehaviour
{
    public void ShowAITalk(string talk)
    {
        
    }

    public void HideAITalk()
    {
        
    }
}
