using UnityEngine;
using UnityEngine.UI;

public class AngelView : MonoBehaviour
{
    [SerializeField] private Image angelImage;
    
    public void Initialize()
    {
        
    }
}
