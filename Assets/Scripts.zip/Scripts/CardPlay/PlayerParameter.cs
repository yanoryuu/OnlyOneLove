using System;
[Serializable]
public class PlayerParameter
{
    public int Brave;
    public int Charm;
    public int Strength;
    public int ActionPoint; // ← 追加
}