using UnityEngine;

public static class CardPlayConst
{

    public static int maxHoldCardNum = 8;
    public static int maxHoldTopicCard = 5;
}
