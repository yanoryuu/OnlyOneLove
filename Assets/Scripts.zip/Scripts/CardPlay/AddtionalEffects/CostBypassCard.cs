using UnityEngine;

public class CostBypassCard : AdditionalEffect
{
    string effectName = "CostBypass";
    public override void PlayCard(CardPlayPresenter presenter)
    {
        
    }
}